

fluidPage(DTOutput("my_dt"),
          highchartOutput("my_hc"))